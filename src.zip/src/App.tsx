import Chessboard from "./components/chessboard";

const App = () => {
  return <Chessboard />;
};

export default App;
